---
title: Brasil
prev: x
up: "d_ams"
next: x
--- **[![](icon://miro-family-home)](home)** **[![](icon://miro-keyboard-double-arrow-left)](${prev}$)** **[![](icon://miro-keyboard-double-arrow-up)](${up}$)** **[![](icon://miro-keyboard-double-arrow-right)](${next}$)**
---

![Attachment-2026-06-01](/demos/Brasil/flag-brasil.png)

![](icon://miro-south-america) **${title}$**
---

^${filename}$^

# ![](icon://miro-ac-unit) GTUs
| GTU | Estados |
| :----: | :----: |
| **[Três Baías](g_3baias)** | PR, SC |
| **[Entrevales](g_entrevales)** | SC |

# ![](icon://miro-location-city) Unipols
![Estados do Brasil](/demos/Brasil/annex/br-estados.png)
* [15] **[Paraná](d_brpr)**
* [23] **[Santa Catarina](d_brsc)**
* [24] **[São Paulo](d_brsp)**

 **[![](icon://miro-family-home)](home)** **[![](icon://miro-keyboard-double-arrow-left)](${prev}$)** **[![](icon://miro-keyboard-double-arrow-up)](${up}$)** **[![](icon://miro-keyboard-double-arrow-right)](${next}$)**
---