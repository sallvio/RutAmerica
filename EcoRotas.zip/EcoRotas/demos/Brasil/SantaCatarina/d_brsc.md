---
title: Santa Catarina
prev: d_brsp
up: d_br
next: x
--- **[![](icon://miro-family-home)](home)** **[![](icon://miro-keyboard-double-arrow-left)](${prev}$)** **[![](icon://miro-keyboard-double-arrow-up)](${up}$)** **[![](icon://miro-keyboard-double-arrow-right)](${next}$)**
---
![flag](/demos/Brasil/SantaCatarina/flag-santa-catarina.png)

![](icon://miro-south-america) **${title}$**
---

^${filename}$^


![](icon://miro-conversion-path) Circuits
---
* [Itajopolis](c_brsc_itajaipolis)

![](icon://miro-location-city) Pólis
---
* [Florianópolis](d_brsc_florianopolis)

---
 **[![](icon://miro-family-home)](home)** **[![](icon://miro-keyboard-double-arrow-left)](${prev}$)** **[![](icon://miro-keyboard-double-arrow-up)](${up}$)** **[![](icon://miro-keyboard-double-arrow-right)](${next}$)**
---