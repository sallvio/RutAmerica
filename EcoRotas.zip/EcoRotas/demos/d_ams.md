---
title: América do Sul
prev: x
up: home
next: x
--- **[![](icon://miro-family-home)](home)** **[![](icon://miro-keyboard-double-arrow-left)](${prev}$)** **[![](icon://miro-keyboard-double-arrow-up)](${up}$)** **[![](icon://miro-keyboard-double-arrow-right)](${next}$)**
---

![UNASUR](/demos/unasur.png)


![](icon://miro-location-city) **${title}$**
---

^${filename}$^

[TOC]

* **🇦🇷 Argentina**
* **🇨🇱 Chile**
* **[🇧🇷 Brasil](d_br)**
* **🇺🇾 Uruguay**


**[![](icon://miro-family-home)](home)** **[![](icon://miro-keyboard-double-arrow-left)](${prev}$)** **[![](icon://miro-keyboard-double-arrow-up)](${up}$)** **[![](icon://miro-keyboard-double-arrow-right)](${next}$)**
---