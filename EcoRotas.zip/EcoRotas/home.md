---
title: Home
---
![Cover](/cover.jpg)

[TOC:]: x

# ![](icon://miro-alt-route) EcoRotas
As rotas do RutAmerica são chamadas EcoRotas.

# ![](icon://miro-location-city) EcoRotas
* **[América do Sul](d_ams)**
